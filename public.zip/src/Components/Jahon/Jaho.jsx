import React from "react";

const Jaho = () => {
  return (
    <div>
      <h1>Jahon</h1>
    </div>
  );
};

export default Jaho;
