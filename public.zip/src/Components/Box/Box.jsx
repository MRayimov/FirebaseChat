import React from "react";
import styled from "styled-components";

const Container = styled("div")`
  width: 250px;
  height: 450px;
  background-color: #ccc;
  border-radius: 20px;
  margin: 10px;
`;

const Image = styled("img")`
  width: 250px;
  border-radius: 20px 20px 0 0;
  height: 300px;
`;
const Box = ({ narxi, rasm, narxiOyiga, nomi }) => {
  return (
    <Container>
      <Image src={rasm} alt="" />
      <h1>{nomi}</h1>
      <p>{narxiOyiga}</p>
      <h4>{narxi}</h4>
    </Container>
  );
};

export default Box;
