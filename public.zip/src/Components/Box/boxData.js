export const boxData = [
  {
    nomi: "Ovosherezka",
    narxi: 105000,
    narxiOyiga: 12500,
    rasm: "https://images.uzum.uz/cn6v6ajifoubkc6s0o5g/original.jpg",
  },
  {
    nomi: "Pilot",
    narxi: 45000,
    narxiOyiga: 5200,
    rasm: "https://images.uzum.uz/cdvet5avtie1lhbe846g/original.jpg",
  },
  {
    nomi: "Pilot",
    narxi: 45000,
    narxiOyiga: 5200,
    rasm: "https://images.uzum.uz/cdvet5avtie1lhbe846g/original.jpg",
  },
];
