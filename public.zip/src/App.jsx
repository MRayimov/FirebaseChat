import React from "react";
import Box from "./Components/Box/Box";
import { boxData } from "./Components/Box/boxData";
const App = () => {
  return (
    <div style={{ display: "flex" }}>
      {boxData.map((element) => (
        <Box
          rasm={element.rasm}
          narxi={element.narxi}
          narxiOyiga={element.narxiOyiga}
          nomi={element.nomi}
        />
      ))}
    </div>
  );
};

export default App;
